<?php
/**
 * DKF Addons Plugin
 *
 * A simple, truly extensible and fully responsive options framework
 * for WordPress themes and plugins. Developed with WordPress coding
 * standards and PHP best practices in mind.
 *
 * Plugin Name:     DKF Addons
 * Plugin URI:      https://dkf.co.id/dkf-core
 * Description:     A plugin required to activate the functionality in the DKF themes.
 * Author:          Limbo Digital
 * Author URI:      https://limbodigital.id
 * Version:         1.0.0
 * Text Domain:     dkf-addons
 * License:         GPL3+
 * License URI:     http://www.gnu.org/licenses/gpl-3.0.txt
 */

// Init
define( 'DKF_ADDONS_VERSION', '1.0.0');
define( 'DKF_ADDONS_URL', plugin_dir_url( __FILE__ ) ); 
define( 'DKF_ADDONS_DIR', plugin_dir_path( __FILE__ ) );

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

// Update Plugin
require_once( DKF_ADDONS_DIR . 'plugin-update-checker/plugin-update-checker.php' );
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://raw.githubusercontent.com/razaqultegar/update-plugin/master/plugins/updates/dkf-addons.json',
	__FILE__,
	'dkf-addons'
);
# Super Toko Core

Super Toko Core is a wordpress plugin for client projects. That is flexible and customizable for setting and changing any elements wihtin a minutes via Powerful Theme Options, you also can customize Google fonts without code very easy and simple.

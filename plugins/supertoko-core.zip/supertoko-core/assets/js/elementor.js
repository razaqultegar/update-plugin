(function ($) {
    'use strict';

    /**
     * Product Deals Carousel
     */
    var productDealsCarouselHandler = function ($scope, $) {
        $scope.find('.mf-elementor-product-deals-carousel').each(function () {
            var $selector = $(this),
                elementSettings = $selector.data('settings'),
                slidesToShow = parseInt(elementSettings.slidesToShow),
                slidesToScroll = parseInt(elementSettings.slidesToScroll);

            $selector.find('ul.products').not('.slick-initialized').slick({
                rtl: $('body').hasClass('rtl'),
                slidesToShow: slidesToShow,
                slidesToScroll: slidesToScroll,
                arrows: true,
                dots: true,
                infinite: 'yes' === elementSettings.infinite,
                prevArrow: '<span class="icon-chevron-left slick-prev-arrow"></span>',
                nextArrow: '<span class="icon-chevron-right slick-next-arrow"></span>',
                autoplay: 'yes' === elementSettings.autoplay,
                autoplaySpeed: parseInt(elementSettings.autoplay_speed),
                responsive: [
                    {
                        breakpoint: 1366,
                        settings: {
                            slidesToShow: slidesToShow > 5 ? 5 : slidesToShow,
                            slidesToScroll: slidesToScroll > 5 ? 5 : slidesToScroll
                        }
                    },
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: slidesToShow > 4 ? 4 : slidesToShow,
                            slidesToScroll: slidesToScroll > 4 ? 4 : slidesToScroll
                        },
                    },
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: slidesToScroll > 3 ? 3 : slidesToScroll
                        }
                    },
                    {
                        breakpoint: 767,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: slidesToScroll > 2 ? 2 : slidesToScroll
                        },
                    }
                ]
            });

            $selector.on('afterChange', function () {
                lazyLoadHandler($selector);
            });

        });
    };

    /**
     * LazyLoad
     */
    var lazyLoadHandler = function ($els) {
        if ($els.length === 0) {
            $els = $('body');
        }
        $els.find('img.lazy').lazyload({
            load: function () {
                $(this).removeClass('lazy');
            }
        });
    };

    var getProductsCarouselHandler = function ($els) {
        var $selector = $els,
            elementSettings = $selector.data('settings'),
            slidesToShow = parseInt(elementSettings.slidesToShow),
            slidesToScroll = parseInt(elementSettings.slidesToScroll);

        $selector.find('ul.products').not('.slick-initialized').slick({
            rtl: $('body').hasClass('rtl'),
            slidesToShow: slidesToShow,
            slidesToScroll: slidesToScroll,
            arrows: true,
            dots: true,
            infinite: 'yes' === elementSettings.infinite,
            prevArrow: '<span class="icon-chevron-left slick-prev-arrow"></span>',
            nextArrow: '<span class="icon-chevron-right slick-next-arrow"></span>',
            autoplay: 'yes' === elementSettings.autoplay,
            autoplaySpeed: parseInt(elementSettings.autoplay_speed),
            speed: parseInt(elementSettings.speed),
            responsive: [
                {
                    breakpoint: 1600,
                    settings: {
                        slidesToShow: slidesToShow > 6 ? 6 : slidesToShow,
                        slidesToScroll: slidesToScroll > 6 ? 6 : slidesToScroll
                    }
                },
                {
                    breakpoint: 1366,
                    settings: {
                        slidesToShow: slidesToShow > 5 ? 5 : slidesToShow,
                        slidesToScroll: slidesToScroll > 5 ? 5 : slidesToScroll
                    }
                },
                {
                    breakpoint: 1200,
                    settings: {
                        slidesToShow: slidesToShow > 4 ? 4 : slidesToShow,
                        slidesToScroll: slidesToScroll > 4 ? 4 : slidesToScroll
                    }
                },
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: slidesToShow > 3 ? 3 : slidesToShow,
                        slidesToScroll: slidesToScroll > 3 ? 3 : slidesToScroll
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: slidesToShow > 2 ? 2 : slidesToShow,
                        slidesToScroll: slidesToScroll > 2 ? 2 : slidesToScroll
                    }
                }
            ]
        });

        $selector.on('afterChange', function () {
            lazyLoadHandler($selector);
        });
    };

    /**
     * CountDown
     */
    var countDownHandler = function ($scope, $) {
        $scope.find('.supertoko-countdown').mf_countdown();
    };


    /**
     * Catagory Tabs Carousel
     */
    var categoryTabsCarouselHandler = function ($scope, $) {
        $scope.find('.mf-category-tabs').each(function () {
            var $selector = $(this);

            $selector.find('ul.tabs-nav').not('.slick-initialized').slick({
                rtl: $('body').hasClass('rtl'),
                slidesToShow: 8,
                prevArrow: '<span class="icon-chevron-left slick-prev-arrow"></span>',
                nextArrow: '<span class="icon-chevron-right slick-next-arrow"></span>',
                infinite: false,
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: 6,
                            slidesToScroll: 6
                        }
                    },
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 4,
                            slidesToScroll: 4
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    }
                ]
            });

            $selector.on('afterChange', function () {
                lazyLoadHandler($selector);
            });
        });
    };

    /**
     * category Tabs
     */
    var categoryTabsHandler = function ($scope, $) {
        $scope.find('.supertoko-tabs').mrtabs();
    };

    /**
     * Product Carousel
     */
    var productsListCarouselHandler = function ($scope, $) {
        var $selector = $scope.find('.mf-products-list-carousel');
        getProductsCarouselHandler($selector);
    };

    /**
     * Product Carousel
     */
    var productsCarouselHandler = function ($scope, $) {
        var $selector = $scope.find('.mf-products-carousel');

        if (!$selector.hasClass('no-infinite')) {
            productCarouselInfinite($selector);
        } else {
            getProductsCarouselHandler($selector);
        }

        function productCarouselInfinite($selector) {

            $(window).on('scroll', function () {

                if ($selector.hasClass('no-infinite')) {
                    return;
                }

                var offSet = 0;

                if ($selector.is(':in-viewport(' + offSet + ')')) {
                    getProductCarouselAjax($selector);
                    $selector.addClass('no-infinite');
                }

            }).trigger('scroll');
        }

        function getProductCarouselAjax($selector) {

            if (typeof mf_elementor_data === 'undefined') {
                return;
            }

            var dataSettings = $selector.find('.mf-products-carousel-loading').data('settings'),
                ajax_url = mf_elementor_data.ajax_url.toString().replace('%%endpoint%%', 'mf_elementor_get_elements');


            $.ajax({
                url: ajax_url,
                dataType: 'json',
                method: 'post',
                data: {
                    params: JSON.stringify(dataSettings),
                    element: 'productsCarousel'
                },
                success: function (response) {
                    $selector.html(response.data);
                    getProductsCarouselHandler($selector);
                    lazyLoadHandler($selector);
                    $(document.body).trigger('supertoko_get_products_ajax_success');
                }
            });
        }

    };

    /**
     * Products Grid
     */

    var productsGridHandler =  function ($scope, $) {
        var $selector = $scope.find('.mf-products-grid');

        if (!$selector.hasClass('no-infinite')) {
            productGridInfinite($selector);
        }

        function productGridInfinite($selector) {

            $(window).on('scroll', function () {

                if ($selector.hasClass('no-infinite')) {
                    return;
                }

                var offSet = 0;

                if ($selector.is(':in-viewport(' + offSet + ')')) {
                    getProductGridAjax($selector);
                    $selector.addClass('no-infinite');
                }

            }).trigger('scroll');
        }

        function getProductGridAjax($selector) {

            if (typeof mf_elementor_data === 'undefined') {
                return;
            }

            var dataSettings = $selector.find('.mf-products-grid-loading').data('settings'),
                ajax_url = mf_elementor_data.ajax_url.toString().replace('%%endpoint%%', 'mf_elementor_get_elements');


            $.ajax({
                url: ajax_url,
                dataType: 'json',
                method: 'post',
                data: {
                    params: JSON.stringify(dataSettings),
                    element: 'productsGrid'
                },
                success: function (response) {
                    $selector.html(response.data);
                    lazyLoadHandler($selector);
                    $(document.body).trigger('supertoko_get_products_ajax_success');
                }
            });
        }
    };

    /**
     * Product Tabs Carousel
     */
    var productTabsCarouselHandler = function ($scope, $) {

        var $selector = $scope.find('.mf-products-tabs-carousel');

        if (!$selector.hasClass('no-infinite')) {
            productTabsCarouselInfinite($selector);
        } else {
            getProductsCarouselHandler($selector);
            productTabsActive($selector);

            $selector.find('.tabs-nav').on('click', 'a', function (e) {
                e.preventDefault();
                getProductsTabsAJAXHandler($(this), $selector, true);
            });
        }

        function productTabsCarouselInfinite($selector) {

            $(window).on('scroll', function () {

                if ($selector.hasClass('no-infinite')) {
                    return;
                }

                var offSet = 0;

                if ($selector.is(':in-viewport(' + offSet + ')')) {
                    getProductTabsCarouselAjax($selector);
                    $selector.addClass('no-infinite');
                }

            }).trigger('scroll');
        }

        function getProductTabsCarouselAjax($selector) {

            if (typeof mf_elementor_data === 'undefined') {
                return;
            }

            var dataSettings = $selector.find('.mf-products-tabs-loading').data('settings'),
                ajax_url = mf_elementor_data.ajax_url.toString().replace('%%endpoint%%', 'mf_elementor_get_elements');


            $.ajax({
                url: ajax_url,
                dataType: 'json',
                method: 'post',
                data: {
                    params: JSON.stringify(dataSettings),
                    element: 'productsTabsCarousel'
                },
                success: function (response) {
                    $selector.html(response.data);
                    getProductsCarouselHandler($selector);
                    lazyLoadHandler($selector);
                    productTabsActive($selector);
                    $(document.body).trigger('supertoko_get_products_ajax_success');
                }
            });
        }
    };

    var productTabsActive = function ($selector) {
        $selector.find('.tabs-nav').on('click', 'a', function (e) {
            e.preventDefault();
            var $this = $(this),
                currentTab = $this.data('href');

            if ($this.hasClass('active')) {
                return;
            }

            $selector.find('.tabs-nav a').removeClass('active');
            $this.addClass('active');
            $selector.find('.tabs-panel').removeClass('active');
            $selector.find('.tabs-' + currentTab).addClass('active');
            lazyLoadHandler($selector.find('.tabs-' + currentTab));
        });
    };


    /**
     * Product Tabs Grid
     */
    var productTabsGridHandler = function ($scope, $) {
        var $selector = $scope.find('.mf-products-tabs-grid');

        if (!$selector.hasClass('no-infinite')) {
            productTabsGridInfinite($selector);
        } else {
            productTabsActive($selector);
            $selector.find('.tabs-nav').on('click', 'a', function (e) {
                e.preventDefault();
                getProductsTabsAJAXHandler($(this), $selector, false);
            });
        }

        function productTabsGridInfinite($selector) {

            $(window).on('scroll', function () {

                if ($selector.hasClass('no-infinite')) {
                    return;
                }

                var offSet = 0;

                if ($selector.is(':in-viewport(' + offSet + ')')) {
                    getProductTabsGridAjax($selector);
                    $selector.addClass('no-infinite');
                }

            }).trigger('scroll');
        }

        function getProductTabsGridAjax($selector) {

            if (typeof mf_elementor_data === 'undefined') {
                return;
            }

            var dataSettings = $selector.find('.mf-products-tabs-loading').data('settings'),
                ajax_url = mf_elementor_data.ajax_url.toString().replace('%%endpoint%%', 'mf_elementor_get_elements');


            $.ajax({
                url: ajax_url,
                dataType: 'json',
                method: 'post',
                data: {
                    params: JSON.stringify(dataSettings),
                    element: 'productsTabsGrid'
                },
                success: function (response) {
                    $selector.html(response.data);
                    lazyLoadHandler($selector);
                    productTabsActive($selector);
                    $(document.body).trigger('supertoko_get_products_ajax_success');
                }
            });
        }


    };


    /**
     * Get Product AJAX
     */
    var getProductsTabsAJAXHandler = function ($el, $tabs, carousel) {

        if (typeof mf_elementor_data === 'undefined') {
            return;
        }

        var tab = $el.data('href'),
            $content = $tabs.find('.tabs-' + tab);

        if ($content.hasClass('tab-loaded')) {
            return;
        }

        var data = {},
            elementSettings = $content.data('settings'),
            ajax_url = mf_elementor_data.ajax_url.toString().replace('%%endpoint%%', 'mf_elementor_load_products');


        $.each(elementSettings, function (key, value) {
            data[key] = value;
        });

        $.post(
            ajax_url,
            data,
            function (response) {
                if (!response) {
                    return;
                }
                $content.html(response.data);
                if (carousel === true) {
                    getProductsCarouselHandler($content.closest('.mf-products-tabs'));
                }
                lazyLoadHandler($content);
                $content.addClass('tab-loaded');
                $(document.body).trigger('supertoko_get_products_ajax_success');
            }
        );
    };

    /**
     * Testimonials Sliders
     */
    var testimonialSlidesHandler = function ($scope, $) {
        $scope.find('.mf-elementor-testimonial-slides').each(function () {
            var $selector = $(this),
                $arrow_wrapper = $(this).find('.arrow-wrapper'),
                elementSettings = $selector.data('settings');

            var options = {
                rtl: $('body').hasClass('rtl'),
                slidesToShow: 2,
                arrows: true,
                dots: true,
                infinite: 'yes' === elementSettings.infinite,
                prevArrow: '<div class="mf-left-arrow"><i class="icon-chevron-left"></i></div>',
                nextArrow: '<div class="mf-right-arrow"><i class="icon-chevron-right"></i></div>',
                appendArrows: $arrow_wrapper,
                autoplay: 'yes' === elementSettings.autoplay,
                autoplaySpeed: parseInt(elementSettings.autoplay_speed),
                speed: parseInt(elementSettings.speed),
                responsive: [
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                        }
                    }
                ]
            };

            $selector.find('.testimonial-list').not('.slick-initialized').slick(options);

            $selector.on('afterChange', function () {
                lazyLoadHandler($selector);
            });

        });
    };

    /**
     * Partner Sliders
     */
    var partnerSlidesHandler = function ($scope, $) {
        $scope.find('.supertoko-partner-carousel').each(function () {
            var $selector = $(this),
                elementSettings = $selector.data('settings');

            $selector.find('.list-item').not('.slick-initialized').slick({
                rtl: $('body').hasClass('rtl'),
                slidesToShow: elementSettings.columns,
                infinite: false,
                arrows: false,
                dots: false,
                autoplay: 'yes' === elementSettings.autoplay,
                autoplaySpeed: parseInt(elementSettings.autoplay_speed),
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: parseInt(elementSettings.autoplay_speed) > 4 ? 4 : elementSettings.autoplay_speed
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 3
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 2
                        }
                    }
                ]
            });

            $selector.on('afterChange', function () {
                lazyLoadHandler($selector);
            });

        });
    };

    var imagesCarouselHandler = function ($scope, $) {
        $scope.find('.mf-images-gallery--slide').each(function () {
            var $selector = $(this),
                elementSettings = $selector.data('settings'),
                slidesToShow = parseInt(elementSettings.slidesToShow),
                slidesToScroll = parseInt(elementSettings.slidesToScroll);

            $selector.find('.images-list').not('.slick-initialized').slick({
                rtl: $('body').hasClass('rtl'),
                slidesToShow: slidesToShow,
                slidesToScroll: slidesToScroll,
                arrows: false,
                dots: 'yes' === elementSettings.dots,
                infinite: 'yes' === elementSettings.infinite,
                prevArrow: '<span class="icon-chevron-left slick-prev-arrow"></span>',
                nextArrow: '<span class="icon-chevron-right slick-next-arrow"></span>',
                autoplay: 'yes' === elementSettings.autoplay,
                autoplaySpeed: parseInt(elementSettings.autoplay_speed),
                speed: parseInt(elementSettings.speed),
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: slidesToShow > 4 ? 4 : slidesToShow,
                            slidesToScroll: slidesToScroll > 4 ? 4 : slidesToScroll
                        }
                    },
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: slidesToShow > 3 ? 3 : slidesToShow,
                            slidesToScroll: slidesToScroll > 3 ? 3 : slidesToScroll
                        }
                    },
                    {
                        breakpoint: 767,
                        settings: {
                            slidesToShow: slidesToShow > 2 ? 2 : slidesToShow,
                            slidesToScroll: slidesToScroll > 2 ? 2 : slidesToScroll
                        }
                    }
                ]
            });

            $selector.on('afterChange', function () {
                lazyLoadHandler($selector);
            });

        });
    };

    var counterHandler = function ($scope, $) {
        $scope.find('.supertoko-counter-els').each(function () {
            var $selector = $(this);
            $selector.find('.counter-value').counterUp();

        });
    };

    /**
     * Product Of Category
     */

    var productsOfCategoryHandler = function ($scope, $) {
        var $selector = $scope.find('.mf-products-of-category'),
            elementSettings = $selector.data('settings');
        if (!$selector.hasClass('no-infinite')) {
            productsOfCategoryAJAX($selector, elementSettings);
        } else {
            bannersCarousel($selector, elementSettings);

        }

        function productsOfCategoryAJAX($selector, elementSettings) {

            $(window).on('scroll', function () {

                if ($selector.hasClass('no-infinite')) {
                    return;
                }

                var offSet = 0;

                if ($selector.is(':in-viewport(' + offSet + ')')) {
                    productsOfCatAjax($selector, elementSettings);
                    $selector.addClass('no-infinite');
                }

            }).trigger('scroll');
        }

        function productsOfCatAjax($selector, elementSettings) {

            if (typeof mf_elementor_data === 'undefined') {
                return;
            }

            var dataSettings = $selector.find('.mf-products-of-category-loading').data('settings'),
                ajax_url = mf_elementor_data.ajax_url.toString().replace('%%endpoint%%', 'mf_elementor_get_elements');


            $.ajax({
                url: ajax_url,
                dataType: 'json',
                method: 'post',
                data: {
                    params: JSON.stringify(dataSettings),
                    element: 'productsOfCat'
                },
                success: function (response) {
                    $selector.html(response.data);
                    bannersCarousel($selector, elementSettings);
                    lazyLoadHandler($selector);
                    $(document.body).trigger('supertoko_get_products_ajax_success');
                }
            });
        }

        /**
         * Catagory Banners Carousel
         */
        function bannersCarousel($selector, elementSettings) {
            $selector.find('.images-list').not('.slick-initialized').slick({
                rtl: $('body').hasClass('rtl'),
                slidesToShow: 1,
                arrows: 'yes' === elementSettings.arrows,
                prevArrow: '<span class="icon-chevron-left slick-prev-arrow"></span>',
                nextArrow: '<span class="icon-chevron-right slick-next-arrow"></span>',
                infinite: 'yes' === elementSettings.infinite,
                autoplay: 'yes' === elementSettings.autoplay,
                autoplaySpeed: parseInt(elementSettings.autoplay_speed),
                dots: 'yes' === elementSettings.dots,
                speed: parseInt(elementSettings.speed),
            });

            $selector.on('afterChange', function () {
                lazyLoadHandler($selector);
            });
        }

    };

    /**
     * Slides Widget
     * @param $scope
     * @param $
     */
    var slideCarouselHandler = function ($scope, $) {
        $scope.find('.mf-slides-wrapper').each(function () {
            var $selector = $(this).find('.mf-slides'),
                elementSettings = $selector.data('slider_options'),
                $arrow_wrapper = $(this).find('.arrows-inner'),
                slidesToShow = parseInt(elementSettings.slidesToShow);

            $selector.not('.slick-initialized').slick({
                rtl: $('body').hasClass('rtl'),
                slidesToShow: slidesToShow,
                arrows: elementSettings.arrows,
                appendArrows: $arrow_wrapper,
                dots: elementSettings.dots,
                infinite: elementSettings.infinite,
                prevArrow: '<span class="slick-prev-arrow"><i class="icon-chevron-left"></i></span>',
                nextArrow: '<span class="slick-next-arrow"><i class="icon-chevron-right"></i></span>',
                autoplay: elementSettings.autoplay,
                autoplaySpeed: parseInt(elementSettings.autoplaySpeed),
                speed: parseInt(elementSettings.speed),
                pauseOnHover: elementSettings.pauseOnHover,
                fade: elementSettings.fade,
                cssEase: elementSettings.fade ? 'linear' : '',
                responsive: []
            });

            $selector.imagesLoaded(function () {
                $selector.closest('.mf-slides-wrapper').removeClass('loading');
            });

            var animation = $selector.data('animation');

            if (animation) {
                $selector
                    .on('beforeChange', function () {
                        var $sliderContent = $selector.find('.mf-slide-content'),
                            $sliderPriceBox = $selector.find('.mf-slide-price-box');

                        $sliderContent.removeClass('animated' + ' ' + animation).hide();

                        $sliderPriceBox.removeClass('animated zoomIn').hide();
                    })
                    .on('afterChange', function (event, slick, currentSlide) {
                        var $currentSlide = $(slick.$slides.get(currentSlide)).find('.mf-slide-content'),
                            $currentPriceBox = $(slick.$slides.get(currentSlide)).find('.mf-slide-price-box');

                        $currentSlide.show().addClass('animated' + ' ' + animation);

                        $currentPriceBox.show().addClass('animated zoomIn');
                    });
            }

            $selector.on('afterChange', function () {
                lazyLoadHandler($selector);
            });
        });
    };

    /**
     * Elementor JS Hooks
     */
    $(window).on("elementor/frontend/init", function () {

        // Product Deals Carousel
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-product-deals-carousel.default",
            productDealsCarouselHandler
        );

        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-product-deals-carousel.default",
            countDownHandler
        );

        //Product Deals Grid

        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-product-deals-grid.default",
            countDownHandler
        );

        // Products of Category
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-products-of-category.default",
            productsOfCategoryHandler
        );


        // Category Tabs
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-category-tabs.default",
            categoryTabsCarouselHandler
        );

        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-category-tabs.default",
            categoryTabsHandler
        );

        // Products Tabs Carousel

        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-product-tabs-carousel.default",
            productTabsCarouselHandler
        );

        // Products Tabs Grid
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-product-tabs-grid.default",
            productTabsGridHandler
        );

        // Products List Carousel
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-products-list-carousel.default",
            productsListCarouselHandler
        );

        // Products Carousel
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-products-carousel.default",
            productsCarouselHandler
        );

        // Testimonial
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-testimonial-slides.default",
            testimonialSlidesHandler
        );

        // Counter
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-counter.default",
            counterHandler
        );

        // Product Grid
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-products-grid.default",
            productsGridHandler
        );

        // All widgets ready
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/widget",
            lazyLoadHandler
        );

        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-countdown.default",
            countDownHandler
        );

        // Partner
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-partner.default",
            partnerSlidesHandler
        );

        // Image Gallery - Slide
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-images-carousel.default",
            imagesCarouselHandler
        );

        // Slides
        elementorFrontend.hooks.addAction(
            "frontend/element_ready/supertoko-slides.default",
            slideCarouselHandler
        );
    });
})
(jQuery);
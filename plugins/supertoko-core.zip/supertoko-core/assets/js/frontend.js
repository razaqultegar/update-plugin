(function ($) {
    'use strict';

    var supertoko = supertoko || {};

    supertoko.init = function () {
        supertoko.$body = $(document.body),
            supertoko.$window = $(window),
            supertoko.$header = $('#masthead');

        this.testimonialSlides();
        this.partnerCarousel();
        this.gmaps();

        // products of category
        this.productsOfCategory();
        this.productsOfCategory2();

        // product tabs
        this.productsTabs();

        // category Tabs
        this.categoryTabs();

        // products carousel
        this.productsCarousel();
        this.dealsOfDay();
        this.productDealsCarousel();

        this.topSelling();
        this.productsListCarousel();

        /*Couterup*/
        if ($.fn.counterUp) {

            $('.supertoko-counter .counter-value').counterUp();
        }

    };

    /**
     * Init testimonial carousel
     */
    supertoko.testimonialSlides = function () {
        if (supertokoShortCode.length === 0 || typeof supertokoShortCode.testimonial === 'undefined') {
            return;
        }

        $.each(supertokoShortCode.testimonial, function (id, testimonialData) {
            var $testimonial = $(document.getElementById(id));

            $testimonial.not('.slick-initialized').slick({
                rtl: (supertokoShortCode.direction === 'true'),
                slidesToShow: 2,
                infinite: testimonialData.autoplay,
                arrows: testimonialData.nav,
                prevArrow: '<div class="mf-left-arrow"><i class="icon-chevron-left"></i></div>',
                nextArrow: '<div class="mf-right-arrow"><i class="icon-chevron-right"></i></div>',
                autoplay: testimonialData.autoplay,
                autoplaySpeed: testimonialData.autoplay_speed,
                speed: 800,
                dots: testimonialData.dot,
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            arrows: false,
                            dots: true
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            arrows: false,
                            dots: true
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            arrows: false,
                            dots: true
                        }
                    }
                ]
            });

            $testimonial.on('afterChange', function () {
                supertoko.lazyLoad($testimonial);
            });
        });
    };

    supertoko.partnerCarousel = function () {
        $('.supertoko-partner.carousel-type').each(function () {
            var $this = $(this),
                $items = $this.find('.list-item'),
                columns = $this.data('columns'),
                autoplay = $this.data('auto'),
                autoplaySpeed = autoplay;

            autoplay = parseInt(autoplaySpeed) > 0 ? true : false;

            $items.not('.slick-initialized').slick({
                rtl: (supertokoShortCode.direction === 'true'),
                slidesToShow: columns,
                infinite: false,
                arrows: false,
                dots: false,
                autoplay: autoplay,
                autoplaySpeed: autoplaySpeed,
                responsive: [
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: 4
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 3
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 2
                        }
                    }
                ]
            });
        });
    };

    supertoko.productsOfCategory = function () {
        if (supertokoShortCode.length === 0 || typeof supertokoShortCode.productsOfCategory === 'undefined') {
            return;
        }
        $.each(supertokoShortCode.productsOfCategory, function (id, productsOfCategoryData) {
            var $viewPort = $(document.getElementById(id));
            supertoko.catBannerCarousel($viewPort.find('.images-list'), productsOfCategoryData);
        });

        $(window).on('scroll', function () {
            var offSet = 0;

            $.each(supertokoShortCode.productsOfCategory, function (id, productsOfCategoryData) {
                var $viewPort = $(document.getElementById(id));
                if (!$viewPort.hasClass('no-infinite')) {
                    if ($viewPort.is(':in-viewport(' + offSet + ')')) {
                        productsOfCatAjax($viewPort, productsOfCategoryData);
                        $viewPort.addClass('no-infinite');
                    }
                }
            });


        }).trigger('scroll');

        function productsOfCatAjax($viewPort, productsOfCategoryData) {
            $.ajax({
                url: supertokoData.ajax_url,
                dataType: 'json',
                method: 'post',
                data: {
                    action: 'supertoko_get_shortcode_ajax',
                    nonce: supertokoData.nonce,
                    params: productsOfCategoryData.params,
                    element: 'productsOfCat'
                },
                success: function (response) {
                    $viewPort.html(response.data);
                    supertoko.lazyLoad($viewPort);
                    supertoko.catBannerCarousel($viewPort.find('.images-list'), productsOfCategoryData);
                    $(document.body).trigger('supertoko_get_products_ajax_success');
                }
            });
        }


    };

    supertoko.productsOfCategory2 = function () {
        if (supertokoShortCode.length === 0 || typeof supertokoShortCode.productsOfCategory2 === 'undefined') {
            return;
        }
        $.each(supertokoShortCode.productsOfCategory2, function (id, productsOfCategoryData) {
            var $viewPort = $(document.getElementById(id));
            supertoko.catBannerCarousel($viewPort.find('.images-list'), productsOfCategoryData);
        });

        $(window).on('scroll', function () {
            var offSet = 0;

            $.each(supertokoShortCode.productsOfCategory2, function (id, productsOfCategoryData) {
                var $viewPort = $(document.getElementById(id));
                if (!$viewPort.hasClass('no-infinite')) {
                    if ($viewPort.is(':in-viewport(' + offSet + ')')) {
                        productsOfCatAjax($viewPort, productsOfCategoryData);
                        $viewPort.addClass('no-infinite');
                    }
                }
            });


        }).trigger('scroll');

        function productsOfCatAjax($viewPort, productsOfCategoryData) {
            $.ajax({
                url: supertokoData.ajax_url,
                dataType: 'json',
                method: 'post',
                data: {
                    action: 'supertoko_get_shortcode_ajax',
                    nonce: supertokoData.nonce,
                    params: productsOfCategoryData.params,
                    element: 'productsOfCat2'
                },
                success: function (response) {
                    $viewPort.html(response.data);
                    supertoko.lazyLoad($viewPort);
                    supertoko.catBannerCarousel($viewPort.find('.images-list'), productsOfCategoryData);
                    supertoko.getproductsCarousel($viewPort.find('.mf-products-tabs'), productsOfCategoryData);
                    supertoko.productTabsActive($viewPort);
                    $(document.body).trigger('supertoko_get_products_ajax_success');
                }
            });
        }

    };

    supertoko.productTabsActive = function($viewPort) {
        $viewPort.find('.tabs-nav').on('click', 'a', function (e) {
            e.preventDefault();
            var $this = $(this),
                currentTab = $this.data('href');

            if ($this.hasClass('active')) {
                return;
            }

            $viewPort.find('.tabs-nav a').removeClass('active');
            $this.addClass('active');
            $viewPort.find('.tabs-panel').removeClass('active');
            $viewPort.find('.tabs-' + currentTab).addClass('active');
        });
    }

    supertoko.catBannerCarousel = function ($id, productsOfCategoryData) {
        $id.not('.slick-initialized').slick({
            rtl: (supertokoShortCode.direction === 'true'),
            slidesToShow: 1,
            arrows: productsOfCategoryData.navigation,
            prevArrow: '<span class="icon-chevron-left slick-prev-arrow"></span>',
            nextArrow: '<span class="icon-chevron-right slick-next-arrow"></span>',
            infinite: productsOfCategoryData.infinite,
            autoplay: productsOfCategoryData.autoplay,
            autoplaySpeed: productsOfCategoryData.autoplay_speed,
            dots: productsOfCategoryData.pagination
        });

        $id.on('afterChange', function () {
            supertoko.lazyLoad($id);
        });
    };

    /**
     * Products Tabs
     */
    supertoko.productsTabs = function () {
        if (supertokoShortCode.length === 0 || typeof supertokoShortCode.productsTabs === 'undefined') {
            return;
        }

        $.each(supertokoShortCode.productsTabs, function (id, productsTabsData) {
            var $viewPort = $(document.getElementById(id));
            supertoko.getproductsCarousel($viewPort, productsTabsData);

            $viewPort.find('.tabs-nav').on('click', 'a', function (e) {
                e.preventDefault();
                var $this = $(this),
                    currentTab = $this.data('href'),
                    $currentEl = $this.closest('.mf-products-tabs');

                if ($this.hasClass('active')) {
                    return;
                }

                $viewPort.find('.tabs-nav a').removeClass('active');
                $this.addClass('active');
                $viewPort.find('.tabs-panel').removeClass('active');
                $viewPort.find('.tabs-' + currentTab).addClass('active');

                getProductsAJAXHandler($this, $currentEl, productsTabsData);
            });
        });

        $(window).on('scroll', function () {
            var offSet = 0;

            $.each(supertokoShortCode.productsTabs, function (id, productsTabsData) {
                var $viewPort = $(document.getElementById(id));
                if (!$viewPort.hasClass('no-infinite')) {
                    if ($viewPort.is(':in-viewport(' + offSet + ')')) {
                        productsTabsAjax($viewPort, productsTabsData);
                        $viewPort.addClass('no-infinite');
                    }
                }
            });


        }).trigger('scroll');

        function productsTabsAjax($viewPort, productsTabsData) {
            $.ajax({
                url: supertokoData.ajax_url,
                dataType: 'json',
                method: 'post',
                data: {
                    action: 'supertoko_get_shortcode_ajax',
                    nonce: supertokoData.nonce,
                    params: productsTabsData.params,
                    element: 'productTabs'
                },
                success: function (response) {
                    $viewPort.find('.tabs-content').html(response.data);
                    supertoko.lazyLoad($viewPort);
                    supertoko.getproductsCarousel($viewPort, productsTabsData);
                    $(document.body).trigger('supertoko_get_products_ajax_success');
                }
            });
        }

        function getProductsAJAXHandler($el, $tabs, productsTabsData) {

            if (typeof wc_add_to_cart_params === 'undefined') {
                return;
            }

            var tab = $el.data('href'),
                $content = $tabs.find('.tabs-' + tab);

            if ($content.hasClass('tab-loaded')) {
                return;
            }

            var data = {
                    'columns': productsTabsData.pro_columns,
                    'products': tab,
                    'per_page': productsTabsData.per_page,
                    'product_cats': productsTabsData.pro_cats,
                },
                ajax_url = wc_add_to_cart_params.wc_ajax_url.toString().replace('%%endpoint%%', 'mf_wpbakery_load_products');

            $.post(
                ajax_url,
                data,
                function (response) {
                    if (!response) {
                        return;
                    }
                    $content.html(response.data);
                    supertoko.lazyLoad($content);
                    supertoko.getproductsCarousel($content, productsTabsData);
                    $content.addClass('tab-loaded');
                }
            );
        };


    };

    /**
     * Products carousel
     */
    supertoko.productsCarousel = function () {
        if (supertokoShortCode.length === 0 || typeof supertokoShortCode.productsCarousel === 'undefined') {
            return;
        }

        $.each(supertokoShortCode.productsCarousel, function (id, productsData) {
            var $viewPort = $(document.getElementById(id));
            supertoko.getproductsCarousel($viewPort, productsData);
        });

        $(window).on('scroll', function () {
            var offSet = 0;

            $.each(supertokoShortCode.productsCarousel, function (id, productsData) {
                var $viewPort = $(document.getElementById(id));
                if (!$viewPort.hasClass('no-infinite')) {
                    if ($viewPort.is(':in-viewport(' + offSet + ')')) {
                        productsCarouselAjax($viewPort, productsData);
                        $viewPort.addClass('no-infinite');
                    }
                }
            });


        }).trigger('scroll');

        function productsCarouselAjax($viewPort, productsData) {
            $.ajax({
                url: supertokoData.ajax_url,
                dataType: 'json',
                method: 'post',
                data: {
                    action: 'supertoko_get_shortcode_ajax',
                    nonce: supertokoData.nonce,
                    params: productsData.params,
                    element: 'productsCarousel'
                },
                success: function (response) {
                    $viewPort.html(response.data);
                    supertoko.lazyLoad($viewPort);
                    supertoko.getproductsCarousel($viewPort, productsData);
                    $(document.body).trigger('supertoko_get_products_ajax_success');
                }
            });
        }


    };

    /**
     * Products carousel
     */
    supertoko.dealsOfDay = function () {
        if (supertokoShortCode.length === 0 || typeof supertokoShortCode.DealsOfDay === 'undefined') {
            return;
        }

        $.each(supertokoShortCode.DealsOfDay, function (id, productsData) {
            var $viewPort = $(document.getElementById(id));
            $viewPort.find('ul.products').not('.slick-initialized').slick({
                rtl: (supertokoShortCode.direction === 'true'),
                slidesToShow: productsData.pro_columns,
                slidesToScroll: productsData.pro_columns,
                arrows: productsData.pro_navigation,
                dots: productsData.pro_navigation,
                infinite: productsData.pro_infinite,
                prevArrow: '<span class="icon-chevron-left slick-prev-arrow"></span>',
                nextArrow: '<span class="icon-chevron-right slick-next-arrow"></span>',
                autoplay: productsData.pro_autoplay,
                autoplaySpeed: productsData.pro_autoplay_speed,
                responsive: [
                    {
                        breakpoint: 1366,
                        settings: {
                            slidesToShow: parseInt(productsData.pro_columns) > 5 ? 5 : productsData.pro_columns,
                            slidesToScroll: parseInt(productsData.pro_columns) > 5 ? 5 : productsData.pro_columns
                        }
                    },
                    {
                        breakpoint: 1200,
                        settings: {
                            slidesToShow: parseInt(productsData.pro_columns) > 4 ? 4 : productsData.pro_columns,
                            slidesToScroll: parseInt(productsData.pro_columns) > 4 ? 4 : productsData.pro_columns
                        }
                    },
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 3
                        }
                    },
                    {
                        breakpoint: 767,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2
                        }
                    }
                ]
            });

            $viewPort.on('afterChange', function () {
                supertoko.lazyLoad($viewPort);
            });
        });
    };


    /**
     * Products carousel
     */
    supertoko.productDealsCarousel = function () {
        if (supertokoShortCode.length === 0 || typeof supertokoShortCode.productDealsCarousel === 'undefined') {
            return;
        }

        $.each(supertokoShortCode.productDealsCarousel, function (id, productsData) {
            var $viewPort = $(document.getElementById(id));
            $viewPort.find('.products').not('.slick-initialized').slick({
                rtl: (supertokoShortCode.direction === 'true'),
                slidesToShow: productsData.pro_columns,
                slidesToScroll: productsData.pro_columns,
                arrows: productsData.pro_navigation,
                infinite: productsData.pro_infinite,
                prevArrow: $viewPort.find('.slick-prev-arrow'),
                nextArrow: $viewPort.find('.slick-next-arrow'),
                autoplay: productsData.pro_autoplay,
                autoplaySpeed: productsData.pro_autoplay_speed
            });

            $viewPort.on('afterChange', function () {
                supertoko.lazyLoad($viewPort);
            });
        });
    };

    /**
     * Top Selling Products
     */
    supertoko.topSelling = function () {
        if (supertokoShortCode.length === 0 || typeof supertokoShortCode.topSelling === 'undefined') {
            return;
        }

        $.each(supertokoShortCode.topSelling, function (id, productsData) {
            var $viewPort = $(document.getElementById(id));
            supertoko.getproductsCarousel($viewPort, productsData);
        });

        $(window).on('scroll', function () {
            var offSet = 0;

            $.each(supertokoShortCode.topSelling, function (id, productsData) {
                var $viewPort = $(document.getElementById(id));
                if (!$viewPort.hasClass('no-infinite')) {
                    if ($viewPort.is(':in-viewport(' + offSet + ')')) {
                        productsCarouselAjax($viewPort, productsData);
                        $viewPort.addClass('no-infinite');
                    }
                }

            });


        }).trigger('scroll');

        function productsCarouselAjax($viewPort, productsData) {
            $.ajax({
                url: supertokoData.ajax_url,
                dataType: 'json',
                method: 'post',
                data: {
                    action: 'supertoko_get_shortcode_ajax',
                    nonce: supertokoData.nonce,
                    params: productsData.params,
                    element: 'topSelling'
                },
                success: function (response) {
                    $viewPort.html(response.data);
                    supertoko.lazyLoad($viewPort);
                    supertoko.getproductsCarousel($viewPort, productsData);
                    $(document.body).trigger('supertoko_get_products_ajax_success');
                }
            });
        }


    };

    /**
     * Top Selling Products
     */
    supertoko.productsListCarousel = function () {
        if (supertokoShortCode.length === 0 || typeof supertokoShortCode.productsListCarousel === 'undefined') {
            return;
        }

        $.each(supertokoShortCode.productsListCarousel, function (id, productsData) {
            var $viewPort = $(document.getElementById(id));
            $viewPort.find('ul.products').not('.slick-initialized').slick({
                rtl: (supertokoShortCode.direction === 'true'),
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows: false,
                dots: productsData.dots,
                infinite: productsData.infinite,
                autoplay: productsData.autoplay,
                autoplaySpeed: productsData.autoplay_speed
            });

            $viewPort.on('afterChange', function () {
                supertoko.lazyLoad($viewPort);
            });
        });

    };

    supertoko.getproductsCarousel = function ($id, productsData) {
        $id.find('ul.products').not('.slick-initialized').slick({
            rtl: (supertokoShortCode.direction === 'true'),
            slidesToShow: productsData.pro_columns,
            slidesToScroll: productsData.pro_columns,
            arrows: productsData.pro_navigation,
            dots: productsData.pro_navigation,
            infinite: productsData.pro_infinite,
            prevArrow: '<span class="icon-chevron-left slick-prev-arrow"></span>',
            nextArrow: '<span class="icon-chevron-right slick-next-arrow"></span>',
            autoplay: productsData.pro_autoplay,
            autoplaySpeed: productsData.pro_autoplay_speed,
            responsive: [
                {
                    breakpoint: 1600,
                    settings: {
                        slidesToShow: parseInt(productsData.pro_columns) > 6 ? 6 : productsData.pro_columns,
                        slidesToScroll: parseInt(productsData.pro_columns) > 6 ? 6 : productsData.pro_columns
                    }
                },
                {
                    breakpoint: 1366,
                    settings: {
                        slidesToShow: parseInt(productsData.pro_columns) > 5 ? 5 : productsData.pro_columns,
                        slidesToScroll: parseInt(productsData.pro_columns) > 5 ? 5 : productsData.pro_columns
                    }
                },
                {
                    breakpoint: 1200,
                    settings: {
                        slidesToShow: parseInt(productsData.pro_columns) > 4 ? 4 : productsData.pro_columns,
                        slidesToScroll: parseInt(productsData.pro_columns) > 4 ? 4 : productsData.pro_columns
                    }
                },
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                }
            ]
        });

        $id.on('afterChange', function () {
            supertoko.lazyLoad($id);
        });
    };

    /**
     * Category Tabs
     */
    supertoko.categoryTabs = function () {
        var $tabs = $('.mf-category-tabs');
        if ($tabs.length < 1) {
            return;
        }

        $tabs.find('ul.tabs-nav').not('.slick-initialized').slick({
            rtl: (supertokoShortCode.direction === 'true'),
            slidesToShow: 8,
            infinite: false,
            prevArrow: '<span class="icon-chevron-left slick-prev-arrow"></span>',
            nextArrow: '<span class="icon-chevron-right slick-next-arrow"></span>',
            responsive: [
                {
                    breakpoint: 1200,
                    settings: {
                        slidesToShow: 6,
                        slidesToScroll: 6
                    }
                },
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 4,
                        slidesToScroll: 4
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                }
            ]
        });
    };

    /**
     * LazyLoad
     */
    supertoko.lazyLoad = function ($els) {
        $els.find('img.lazy').lazyload({
            load: function () {
                $(this).removeClass('lazy');
            }
        }).trigger('appear');
    };


    /**
     * Init Google maps
     */
    supertoko.gmaps = function () {

        if (supertokoShortCode.length === 0 || typeof supertokoShortCode.map === 'undefined') {
            return;
        }

        var mapOptions = {
                scrollwheel: false,
                draggable: true,
                zoom: 10,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                panControl: false,
                zoomControl: true,
                zoomControlOptions: {
                    style: google.maps.ZoomControlStyle.SMALL
                },
                scaleControl: false,
                streetViewControl: false

            },
            customMap;

        var bounds = new google.maps.LatLngBounds();
        var infoWindow = new google.maps.InfoWindow();


        $.each(supertokoShortCode.map, function (id, mapData) {
            var map_color = mapData.map_color,
                road_highway_color = mapData.road_highway_color;

            var styles =
                [
                    {
                        'featureType': 'administrative',
                        'elementType': 'labels.text.fill',
                        'stylers': [{'color': '#444444'}]
                    },
                    {
                        'featureType': 'landscape',
                        'elementType': 'all',
                        'stylers': [{'color': '#f2f2f2'}]
                    },
                    {
                        'featureType': 'landscape',
                        'elementType': 'geometry.fill',
                        'stylers': [{'color': '#f2f2f2'}]
                    },
                    {
                        'featureType': 'landscape',
                        'elementType': 'geometry.stroke',
                        'stylers': [{'color': '#000000'}]
                    },
                    {
                        'featureType': 'poi',
                        'elementType': 'all',
                        'stylers': [{'visibility': 'off'}]
                    },
                    {
                        'featureType': 'road',
                        'elementType': 'all',
                        'stylers': [{'saturation': -100}, {'lightness': 45}]
                    },
                    {
                        'featureType': 'road.highway',
                        'elementType': 'all',
                        'stylers': [{'visibility': 'simplified'}]
                    },
                    {
                        'featureType': 'road.highway',
                        'elementType': 'geometry.fill',
                        'stylers': [{'color': road_highway_color}]
                    },
                    {
                        'featureType': 'road.arterial',
                        'elementType': 'labels.icon',
                        'stylers': [{'visibility': 'off'}]
                    },
                    {
                        'featureType': 'road.local',
                        'elementType': 'geometry.fill',
                        'stylers': [{'color': '#e6e6e6'}]
                    },
                    {
                        'featureType': 'transit',
                        'elementType': 'all',
                        'stylers': [{'visibility': 'off'}]
                    },
                    {
                        'featureType': 'water',
                        'elementType': 'all',
                        'stylers': [{'visibility': 'on'}, {'color': map_color}]
                    }
                ];

            customMap = new google.maps.StyledMapType(styles,
                {name: 'Styled Map'});

            if (mapData.number > 1) {
                mutiMaps(infoWindow, bounds, mapOptions, mapData, id, styles, customMap);
            } else {
                singleMap(mapOptions, mapData, id, styles, customMap);
            }

        });
    };

    function singleMap(mapOptions, mapData, id, styles, customMap) {
        var map,
            marker,
            location = new google.maps.LatLng(mapData.lat, mapData.lng);

        // Update map options
        mapOptions.zoom = parseInt(mapData.zoom, 10);
        mapOptions.center = location;
        mapOptions.mapTypeControlOptions = {
            mapTypeIds: [google.maps.MapTypeId.ROADMAP]
        };

        // Init map
        map = new google.maps.Map(document.getElementById(id), mapOptions);

        // Create marker options
        var markerOptions = {
            map: map,
            position: location
        };
        if (mapData.marker) {
            markerOptions.icon = {
                url: mapData.marker
            };
        }

        map.mapTypes.set('map_style', customMap);
        map.setMapTypeId('map_style');

        // Init marker
        marker = new google.maps.Marker(markerOptions);

        if (mapData.info) {
            var infoWindow = new google.maps.InfoWindow({
                content: '<div class="info-box mf-map">' + mapData.info + '</div>',
                maxWidth: 600
            });

            google.maps.event.addListener(marker, 'click', function () {
                infoWindow.open(map, marker);
            });
        }
    }

    function mutiMaps(infoWindow, bounds, mapOptions, mapData, id, styles, customMap) {

        // Display a map on the page
        mapOptions.zoom = parseInt(mapData.zoom, 10);
        mapOptions.mapTypeControlOptions = {
            mapTypeIds: [google.maps.MapTypeId.ROADMAP]
        };

        var map = new google.maps.Map(document.getElementById(id), mapOptions);
        map.mapTypes.set('map_style', customMap);
        map.setMapTypeId('map_style');
        for (var i = 0; i < mapData.number; i++) {
            var lats = mapData.lat,
                lng = mapData.lng,
                info = mapData.info;

            var position = new google.maps.LatLng(lats[i], lng[i]);
            bounds.extend(position);

            // Create marker options
            var markerOptions = {
                map: map,
                position: position
            };
            if (mapData.marker) {
                markerOptions.icon = {
                    url: mapData.marker
                };
            }

            // Init marker
            var marker = new google.maps.Marker(markerOptions);

            // Allow each marker to have an info window
            googleMaps(infoWindow, map, marker, info[i]);

            // Automatically center the map fitting all markers on the screen
            map.fitBounds(bounds);
        }
    }

    function googleMaps(infoWindow, map, marker, info) {
        google.maps.event.addListener(marker, 'click', function () {
            infoWindow.setContent(info);
            infoWindow.open(map, marker);
        });
    }

    /**
     * Document ready
     */
    $(function () {
        supertoko.init();
    });

})(jQuery);
<?php

class Payment_Icon {
	protected $loader;
	protected $plugin_name;
  protected $version;
  
	public function __construct() {
		$this->plugin_name = 'supertoko-core';
    $this->version = SUPERTOKO_CORE_VERSION;
		$this->load_dependencies();
		$this->define_admin_hooks();
		$this->define_public_hooks();
	}

	private function load_dependencies() {
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/payment/class-payment-icon-loader.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/payment/class-payment-icon-admin.php';
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/payment/class-payment-icon-public.php';

		$this->loader = new Payment_Icon_Loader();
	}

	private function define_admin_hooks() {
		$plugin_admin = new Payment_Icon_Admin( $this->get_plugin_name(), $this->get_version() );
    $this->loader->add_action('init', $plugin_admin, 'hook_form_fields_modifier', 20);
	}

	private function define_public_hooks() {
		$plugin_public = new Payment_Icon_Public( $this->get_plugin_name(), $this->get_version() );
    $this->loader->add_filter('woocommerce_gateway_icon', $plugin_public, 'modify_icon', 20, 2);
	}

	public function run() {
		$this->loader->run();
	}

	public function get_plugin_name() {
		return $this->plugin_name;
	}

	public function get_loader() {
		return $this->loader;
	}

	public function get_version() {
		return $this->version;
	}
}
<?php

class Payment_Icon_Admin {
	private $plugin_name;

	private $version;

	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

  public function __call($name, $arguments) {
    if ( strpos($name, 'add_icon_form_field_to_') === 0 &&  $id = str_replace('add_icon_form_field_to_', '', $name)) {
      return $this->add_icon_form_field($id, $arguments[0]);
    }
  }

  public function hook_form_fields_modifier() {
    if (!function_exists('WC')) {
      return;
    }

    foreach (WC()->payment_gateways()->get_payment_gateway_ids() as $id) {                
      add_filter('woocommerce_settings_api_form_fields_' . $id, array($this, 'add_icon_form_field_to_' . $id));
    }
  }

  public function add_icon_form_field($id, $form_fields) {
    $form_fields['payment_icon'] = array(
      'title'       => esc_html__( 'Icon', 'supertoko-core' ),
      'type'        => 'text',
      'description' => esc_html__( 'Enter an image URL to change the icon.', 'supertoko-core' ),
      'desc_tip'    => true,
      'default'     => '',
    );

    return $form_fields;
  }
}
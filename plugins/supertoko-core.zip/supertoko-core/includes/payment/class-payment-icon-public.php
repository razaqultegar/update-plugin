<?php

class Payment_Icon_Public {
	private $plugin_name;

	private $version;

	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

  public function modify_icon($icon = '', $id = '') {
    if (!$id) {
      return $icon;
    }

    $payment_gateways = WC()->payment_gateways()->payment_gateways();

    if (!isset($payment_gateways[$id])) {
      return $icon;
    }

    $payment_gateway = $payment_gateways[$id]; 
    $custom_icon = $payment_gateway->get_option('payment_icon');

    if (!$custom_icon) {
      return $icon;
    }

    return '<img src="' . WC_HTTPS::force_https_url(esc_url($custom_icon)) . '" alt="' . esc_attr( $payment_gateway->get_title() ) . '" align="right" />';
  }
}
=== Super Toko Core ===

Contributors: razaqultegar
Tags: theme-options
Requires at least: 4.6
Tested up to: 4.7
Stable tag: 4.3
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A starter theme called Super Toko Core, or underscores.

== Description ==

Super Toko Core is a wordpress plugin for client projects. That is flexible and customizable for setting and changing any elements wihtin a minutes via Powerful Theme Options, you also can customize Google fonts without code very easy and simple.

== Installation ==

1. Upload the entire urna-core folder to the /wp-content/plugins/ directory.
2. Activate the plugin through the ‘Plugins’ menu in WordPress.

== Changelog ==

= 1.1.0 =
*Release Date - January 30 2020*
- Add Payment Icon
- Fix Elementor Widgets

= 1.0.0 =
*Release Date - December 12 2019*
- Initial release
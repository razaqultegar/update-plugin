=== Super Toko Core ===

Contributors: Razaqul Tegar
Tags: translation-ready, custom-background, theme-options, custom-menu, post-formats, threaded-comments
Requires at least: 4.0
Tested up to: 5.3.2
Stable tag: 4.0.3
License: GPLv3 or later

A starter theme called Super Toko Core, or underscores.

== Description ==

Super Toko Core is a wordpress plugin for client projects. That is flexible and customizable for setting and changing any elements wihtin a minutes via Powerful Theme Options, you also can customize Google fonts without code very easy and simple.

== Installation ==

1. Upload the entire urna-core folder to the /wp-content/plugins/ directory.
2. Activate the plugin through the ‘Plugins’ menu in WordPress.

== Changelog ==

= 1.1.0 =
*Release Date - January 30 2020*
- Add Payment Icon
- Fix Elementor Widgets

= 1.0.0 =
*Release Date - December 12 2019*
- Initial release
=== Super Toko Core ===

Contributors: razaqultegar
Tags: ecommerce, e-commerce, theme-options
Requires at least: 5.0
Tested up to: 5.3
Stable tag: 1.1.0
Requires PHP: 5.2.4
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

A starter theme called Super Toko Core, or underscores.

== Description ==

Super Toko Core is a wordpress plugin for client projects. That is flexible and customizable for setting and changing any elements wihtin a minutes via Powerful Theme Options, you also can customize Google fonts without code very easy and simple.

== Installation ==

1. Upload the entire urna-core folder to the /wp-content/plugins/ directory.
2. Activate the plugin through the ‘Plugins’ menu in WordPress.

== Changelog ==

= 1.1.0 - 2020-01-30 =
* Add Payment Icon
* Fix Elementor Widgets

= 1.0.0 - 2019-12-26 =
* Initial release
<?php
/**
 * Super Toko Core Plugin
 *
 * A simple, truly extensible and fully responsive options framework
 * for WordPress themes and plugins. Developed with WordPress coding
 * standards and PHP best practices in mind.
 *
 * Plugin Name:     Super Toko Core
 * Plugin URI:      https://supertoko.my.id/supertoko-core/
 * Description:     A plugin required to activate the functionality in the Super Toko themes.
 * Author:          Razaqul Tegar
 * Author URI:      https://razaqultegar.com/
 * Version:         1.0.0
 * Text Domain:     supertoko-core
 * License:         GPL3+
 * License URI:     http://www.gnu.org/licenses/gpl-3.0.txt
 */

define( 'SUPERTOKO_CORE_VERSION', '1.0.0');
define( 'SUPERTOKO_CORE_URL', plugin_dir_url( __FILE__ ) ); 
define( 'SUPERTOKO_CORE_DIR', plugin_dir_path( __FILE__ ) );

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

// Init
function supertoko_core_init() {
	$demo_mode = apply_filters( 'supertoko_core_register_demo_mode', false );
	if ( $demo_mode ) {
		supertoko_core_init_redux();
	}
}
add_action( 'init', 'supertoko_core_init', 100 );

// Elementor
function supertoko_init_elementor() {
	if ( ! did_action( 'elementor/loaded' ) ) {
		return;
	}

	include_once( SUPERTOKO_CORE_DIR . 'includes/elementor.php' );
	include_once( SUPERTOKO_CORE_DIR . 'includes/elementor-ajaxloader.php' );
}
add_action( 'plugins_loaded', 'supertoko_init_elementor' );

// Redux Framework
if ( !class_exists( 'ReduxFramework' ) && file_exists( SUPERTOKO_CORE_DIR . 'includes/redux-framework/ReduxCore/framework.php' ) ) {
	require_once( SUPERTOKO_CORE_DIR . 'includes/redux-framework/ReduxCore/framework.php' );
	require_once( SUPERTOKO_CORE_DIR . 'includes/loader.php' );
	define( 'SUPERTOKO_CORE_ACTIVED', true );
} else {
define( 'SUPERTOKO_CORE_ACTIVED', true );
}

// Update Plugin
require_once( SUPERTOKO_CORE_DIR . 'plugin-update-checker/plugin-update-checker.php' );
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://github.com/razaqultegar/update-plugin/blob/master/plugins/updates/supertoko-core.json',
	__FILE__,
	'supertoko-core'
);

// Payment Icon
require_once( SUPERTOKO_CORE_DIR . 'includes/payment.php' );
function run_payment_icon() {
	$plugin = new Payment_Icon();
	$plugin->run();
}
run_payment_icon();